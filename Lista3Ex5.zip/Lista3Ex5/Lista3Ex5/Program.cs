﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3Ex5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor = 0;
            double result = 0;
            int cont = 0;

            Console.WriteLine("\n---------Exercício 5 da Lista 3---------\n");

            Console.Write("Digite um Valor para a Tabuada: ");
            valor = double.Parse(Console.ReadLine());

            while (valor <= 0)
            {
                Console.Write("Digite o Valor Novamente, Porém Positivo: ");
                valor = double.Parse(Console.ReadLine());
            }

            do
            {
                cont++;
                result = valor * cont;
                Console.WriteLine("{0} x {1} = {2}", cont, valor, result);

            }while(cont < 10);
        }
    }
}
